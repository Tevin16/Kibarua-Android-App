package com.example.tevin.kibarua;

public class ho_interfaceTest {
}
