package com.example.tevin.kibarua;

public class IntermediateTable {
    private int sp_id, sid;

    //empty constructor
    public IntermediateTable(){}

    public void setSID(int sid){this.sid = sid;}
    public int getSID(){ return sid; }

    public void setSp_id(int sp_id){this.sp_id = sp_id;}
    public int getSP_id(){ return sp_id; }

}
