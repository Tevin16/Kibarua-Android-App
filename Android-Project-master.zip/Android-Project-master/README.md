# Android-Project
On-Demand Home Repair Services App

Group members:

Jason Smith 

- Student ID: 300043461

Joseph Peters 

- Student ID: 300024207

Bradley Rose

- Student ID: 8746930

Nicolas Gardin

- Student ID: 8714215

GitHub Repository link:

- https://github.com/JasonSmith03/Android-Project.git


- Admin username: Silver Rivals
- Admin password: admin1

Build Status:

[![CircleCI](https://circleci.com/gh/JasonSmith03/Android-Project.svg?style=svg&circle-token=354b88b2c9b2bf29d620f4b6d7cb9bd9b9411c37)](https://circleci.com/gh/JasonSmith03/Android-Project)
